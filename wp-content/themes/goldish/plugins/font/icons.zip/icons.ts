export type IconsId =
  | "discount"
  | "email"
  | "map-pin"
  | "moneyback"
  | "phone"
  | "quality"
  | "romb"
  | "shipping"
  | "support"
  | "time"
  | "world";

export type IconsKey =
  | "Discount"
  | "Email"
  | "MapPin"
  | "Moneyback"
  | "Phone"
  | "Quality"
  | "Romb"
  | "Shipping"
  | "Support"
  | "Time"
  | "World";

export enum Icons {
  Discount = "discount",
  Email = "email",
  MapPin = "map-pin",
  Moneyback = "moneyback",
  Phone = "phone",
  Quality = "quality",
  Romb = "romb",
  Shipping = "shipping",
  Support = "support",
  Time = "time",
  World = "world",
}

export const ICONS_CODEPOINTS: { [key in Icons]: string } = {
  [Icons.Discount]: "61697",
  [Icons.Email]: "61698",
  [Icons.MapPin]: "61699",
  [Icons.Moneyback]: "61700",
  [Icons.Phone]: "61701",
  [Icons.Quality]: "61702",
  [Icons.Romb]: "61703",
  [Icons.Shipping]: "61704",
  [Icons.Support]: "61705",
  [Icons.Time]: "61706",
  [Icons.World]: "61707",
};
